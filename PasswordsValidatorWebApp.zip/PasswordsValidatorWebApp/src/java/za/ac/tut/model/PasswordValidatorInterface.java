/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package za.ac.tut.model;

/**
 *
 * @author Alex
 */
public interface PasswordValidatorInterface 
{
    public int THRESHOLD = 2;
    public int MINIMUM_LENGTH = 8;
    
    public boolean isPasswordValid(String password);
    
}
