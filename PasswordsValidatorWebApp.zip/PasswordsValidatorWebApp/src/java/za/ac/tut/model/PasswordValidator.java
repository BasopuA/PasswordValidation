package za.ac.tut.model;

/**
 *
 * @author Alex
 */
public class PasswordValidator implements PasswordValidatorInterface {

    @Override
    public boolean isPasswordValid(String password) {
        // Call the private method to validate the password
        return isThePasswordValid(password);
    }

    private boolean isThePasswordValid(String password) {
        boolean isValid = false;
        char charAtIndex;
        int cntLetters = 0, cntDigits = 0, cntSpecialChars = 0;

        // Check if the password meets the minimum length requirement
        if (password.length() >= MINIMUM_LENGTH) {
            for (int i = 0; i < password.length(); i++) {
                charAtIndex = password.charAt(i);

                // Count letters, digits, and special characters
                if (Character.isLetter(charAtIndex)) {
                    cntLetters++;
                } else if (Character.isDigit(charAtIndex)) {
                    cntDigits++;
                } else {
                    cntSpecialChars++;
                }
            }

            // Check if the password meets the threshold requirements
            if (cntLetters >= THRESHOLD && cntDigits >= THRESHOLD && cntSpecialChars >= THRESHOLD) {
                isValid = true;
            }
        }

        return isValid;
    }
}