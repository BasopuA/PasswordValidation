package za.ac.tut.web;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import za.ac.tut.model.PasswordValidator;

/**
 *
 * @author Alex
 */
public class PasswordValidatorServlet extends HttpServlet {


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession();
        String password = request.getParameter("password");
        
        PasswordValidator pvi = new PasswordValidator();
        boolean isValid = pvi.isPasswordValid(password);
        
        updateSession(session, password, isValid);
        request.setAttribute("isValid", isValid);
        request.setAttribute("password", password);
        
        RequestDispatcher disp = request.getRequestDispatcher("password_validation_outcome.jsp");
        disp.forward(request, response);
        
    }
    private void updateSession(HttpSession session,String password, boolean isValid)
    {
        Integer numPasswordsChecked = (Integer)session.getAttribute("numPasswordsChecked");
        Integer numValidPasswords = (Integer)session.getAttribute("numValidPasswords");
        Integer numInvalidPasswords =  (Integer)session.getAttribute("numInvalidPasswords");
        List<String> passwords = (List<String>) session.getAttribute("passwords");
        List<String> validPasswords = (List<String>) session.getAttribute("validPasswords"); 
        List<String> invalidPasswords = (List<String>) session.getAttribute("invalidPasswords"); 
        
        passwords.add(password);
        
        if(isValid)
        {
            numValidPasswords++;
            validPasswords.add(password);
        }
        else
        {
            numInvalidPasswords++;
            invalidPasswords.add(password);
        }
        numPasswordsChecked++;
        
        session.setAttribute("numPasswordsChecked", numPasswordsChecked);
        session.setAttribute("numValidPasswords", numValidPasswords);
        session.setAttribute("numInvalidPasswords", numInvalidPasswords);
        session.setAttribute("passwords", passwords);
        session.setAttribute("validPasswords", validPasswords);
        session.setAttribute("invalidPasswords", invalidPasswords);
    }

}
