/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package za.ac.tut.web;

import jakarta.servlet.RequestDispatcher;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Alex
 */
public class StartSessionServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        HttpSession session = request.getSession(true);
        String name = request.getParameter("name");
        
        initializeSession(session, name);
        RequestDispatcher disp = request.getRequestDispatcher("menu.jsp");
        disp.forward(request, response);
        
    }
    private void initializeSession(HttpSession session, String name)
    {
        Integer numPasswordsChecked = 0, numValidPasswords =0, numInvalidPasswords = 0;
        List<String> passwords = new ArrayList<>();
        List<String> validPasswords = new ArrayList<>();
        List<String> invalidPasswords = new ArrayList<>();
        
        session.setAttribute("numPasswordsChecked", numPasswordsChecked);
        session.setAttribute("numValidPasswords", numValidPasswords);
        session.setAttribute("numInvalidPasswords", numInvalidPasswords);
        session.setAttribute("passwords", passwords);
        session.setAttribute("validPasswords", validPasswords);
        session.setAttribute("invalidPasswords", invalidPasswords);
        session.setAttribute("name", name);
    }

}
